# Importing necessary libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import matplotlib.pyplot as plt

# Open file manually and split columns
with open("C:\\Users\\Fetcy Exshelya\\OneDrive\Desktop\\skillcraft task relevant folders\\Bank_Marketing_DT\\bank-full.csv","r",encoding="utf-8") as file:
    header = file.readline().strip().replace('"', '').split(";")  # clean and split header
    data = [line.strip().replace('"', '').split(";") for line in file]  # clean and split data

# Create DataFrame
df = pd.DataFrame(data, columns=header)

# Display first 5 rows
print("First 5 rows of data:")
print(df.head())

# Encode categorical variables
label_encoders = {}
for column in df.columns:
    if df[column].dtype == 'object':
        le = LabelEncoder()
        df[column] = le.fit_transform(df[column])
        label_encoders[column] = le

# Features and target
print(df.columns.tolist())
X = df.drop('y', axis=1)
y = df['y']

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train Decision Tree Classifier
clf = DecisionTreeClassifier(criterion='entropy', max_depth=5, random_state=42)
clf.fit(X_train, y_train)

# Predict on test data
y_pred = clf.predict(X_test)

# Evaluation
print("\nAccuracy Score:", accuracy_score(y_test, y_pred))
print("\nClassification Report:\n", classification_report(y_test, y_pred))
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))

# Visualize the tree
plt.figure(figsize=(20, 10))
plot_tree(clf, feature_names=X.columns, class_names=['no', 'yes'], filled=True)
plt.title("Decision Tree - Customer Purchase Prediction")
plt.show()
